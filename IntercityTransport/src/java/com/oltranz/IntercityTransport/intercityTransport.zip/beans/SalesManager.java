/*
* To change this license header, choose License Headers in Project Properties.
* To change this template file, choose Tools | Templates
* and open the template in the editor.
*/
package com.oltranz.IntercityTransport.beans;


import com.oltranz.IntercityTransport.entities.ProfileOnSellingDevice;
import com.oltranz.IntercityTransport.entities.Transporter;
import com.oltranz.IntercityTransport.entities.SellingDevice;
import com.oltranz.IntercityTransport.models.CardPaymentOnPOSRequestModel;
import com.oltranz.IntercityTransport.models.ResultObject;
import javax.ejb.Stateless;
import javax.ejb.LocalBean;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
//import org.eclipse.persistence.config.HintValues;
//import org.eclipse.persistence.config.QueryHints;

/**
 *
 * @author manzi
 */
@Stateless
@LocalBean
public class SalesManager {
    @PersistenceContext(unitName = "IntercityTransportPU")
    private  EntityManager em;
    
    public List<SellingDevice> getSellingDevicesList(){
        Query query = em.createQuery("select d from SellingDevice d");
        // query.setHint(QueryHints.CACHE_USAGE, HintValues.FALSE);
        List<SellingDevice>list=query.getResultList();
        return list;
    }
    
    public ResultObject processCardPaymentOnPOSRequest(CardPaymentOnPOSRequestModel payment){
        ResultObject resultObject= new ResultObject();
        //on receiving payment request
        //1. check validity of (profileId, deviceId) validity
        Query query = em.createQuery("select p from ProfileOnSellingDevice p where p.profileOnSellingDevicePK.deviceId=:deviceId and p.profileOnSellingDevicePK.profileId=:profileId");
        query.setParameter("deviceId",Integer.parseInt(payment.getDeviceId()));
        query.setParameter("profileId",Integer.parseInt(payment.getProfileId()));
        List<ProfileOnSellingDevice> device_profileList=query.getResultList();
        if(device_profileList.isEmpty()){
            resultObject.setMessage("Wrong Profile Id");
            resultObject.setObjectClass(ProfileOnSellingDevice.class);
            return resultObject;
        }
//2. get bus on which device is located
        //3. get owner of the bus (bus_owner)
        //3. get transporter owner of the profile (profile_device_owner) and device used
        //4. get transporter owner of the of the bus wallet (bus_owner_wallet)
        //
        //5. check card validity
        //6. get customer owner of the card used
        //7. get customer's wallet
        //8. get contracts on which current bus is attached and for which [profile_device_owner] is the contracting_transporter
        //9. Out of the contracts get those with transactional payment
        //10. check if the balance of customer wallet is greater than the total request payment
        //
        //11. proceed with creating sale_transaction, setting each variable with data from above variables, save it and get its new id in [Sale_transaction_id]
        //
        //12 remove amount needed from customer wallet
        //  -create wallet tranaction for it setting [refTrans_id]=[Sale_transaction_id],[refTransType_id]=[bus_ticket_purchase_type]
        //13 `
        //13 get list of all the (contractor,walletId, percentage)
        //   set remainingMount=AmountPaid
        //  Add the percentage of the paid amount the balance of each wallet
        //  create wallet tranaction for it setting [refTrans_id]=[Sale_transaction_id],[refTransType_id]=[bus_ticket_purchase_type]
        //   remainingMount+=AmountAddedToTheabove
        //14.
        
        return resultObject;
    }
    
    public List<SellingDevice> getSellingDevicesList(Transporter transporter){
        Query query = em.createQuery("select d from SellingDevice d where ");
        // query.setHint(QueryHints.CACHE_USAGE, HintValues.FALSE);
        List<SellingDevice>list=query.getResultList();
        return list;
    }
    
    public ResultObject processCardPayment(CardPaymentOnPOSRequestModel payment){
        ResultObject resultObject=new ResultObject();
        return resultObject;
        
    }
    
    
}
