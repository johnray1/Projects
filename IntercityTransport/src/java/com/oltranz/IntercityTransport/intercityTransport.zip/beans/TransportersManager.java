/*
* To change this license header, choose License Headers in Project Properties.
* To change this template file, choose Tools | Templates
* and open the template in the editor.
*/
package com.oltranz.IntercityTransport.beans;


import com.oltranz.IntercityTransport.entities.Transporter;
import com.oltranz.IntercityTransport.entities.UserRole;
import com.oltranz.IntercityTransport.entities.UserRoleForTransporter;
import com.oltranz.IntercityTransport.entities.UserRoleForTransporterPK;
import com.oltranz.IntercityTransport.models.ResultObject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.ejb.Stateless;
import javax.ejb.LocalBean;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
//import org.eclipse.persistence.config.HintValues;
//import org.eclipse.persistence.config.QueryHints;

/**
 *
 * @author manzi
 */
@Stateless
@LocalBean
public class TransportersManager {
    @PersistenceContext(unitName = "IntercityTransportPU")
    private  EntityManager em;
    
    public ResultObject getTransporter(Integer transporterId){
        ResultObject resultObject=new ResultObject();
        Transporter transporter=em.find(Transporter.class,transporterId);
        
        if(transporter!=null){
            resultObject.setMessage("Transporter Well found and returned!");
            resultObject.setObject(transporter);
            resultObject.setObjectClass(Transporter.class);
            return resultObject;
        }else{
            resultObject.setMessage("Transporter with given Id not found!");
            resultObject.setObject(null);
            resultObject.setObjectClass(Transporter.class);
            return resultObject;
        }
    }
    
    public ResultObject createTransporter(Transporter newTransporter){
        Transporter transporter=new Transporter();
        transporter.setName(newTransporter.getName());
        transporter.setDescr(newTransporter.getDescr());
        em.persist(transporter);
        
        //after creating the transporter, a role the represent this transorter
        //must be also created in userRoleForTransporter
        
        //So we create first an new user role
        UserRole userRole= new UserRole();
        userRole.setDescr("A role that Transporter '"+ transporter.getName()+"' Staff are considered to have");
        userRole.setName("Transporter '"+ transporter.getName()+"' Staff");
        userRole.setTypeId(3); //as per system initialized roleType 3 is for transporters staff
        
        em.persist(userRole);
        
        UserRoleForTransporterPK userRoleForTransporterPK=new UserRoleForTransporterPK(userRole.getId(),transporter.getId());
        UserRoleForTransporter userRoleForTransporter=new UserRoleForTransporter(userRoleForTransporterPK);
        
        em.persist(userRoleForTransporter);
        
        ResultObject resultObject=new ResultObject();
        resultObject.setMessage("New transporter successfully created and its staff role created");
        resultObject.setObject(transporter);
        resultObject.setObjectClass(Transporter.class);
        return resultObject;
    }
    
    public ResultObject updateTransporter(Transporter editTransporter){
        ResultObject resultObject=new ResultObject();
        Transporter transporter=em.find(Transporter.class, editTransporter.getId());
        
        
        if(transporter==null){
            resultObject.setMessage("No transporter with id of the given one is found!");
            resultObject.setObject("FAILURE");
            resultObject.setObjectClass(String.class);
            return resultObject;
        }
        transporter.setName(editTransporter.getName());
        transporter.setDescr(editTransporter.getDescr());
        em.merge(transporter);
        
        
        resultObject.setMessage("Transporter successfully updated");
        resultObject.setObject(transporter);
        resultObject.setObjectClass(Transporter.class);
        return resultObject;
    }
    
    public ResultObject getTransportersList(){
        ResultObject resultObject= new ResultObject();
        Query query;
        
        query=em.createQuery("select t from Transporter t  ");
        
        List<Transporter> transportersList=(List<Transporter>)query.getResultList();
        
        resultObject.setObject(transportersList);
        resultObject.setObjectClass(ArrayList.class);
        
        if(transportersList.isEmpty()){
            resultObject.setMessage("There are no Transporter in the system");
        }
        else{
            resultObject.setMessage(transportersList.size()+" Transporters were found");
        }
               
        return resultObject;
        
    }
    
    public ResultObject deleteTransporter(Transporter transporter2Delete){
        ResultObject resultObject=new ResultObject();
        Transporter transporter=em.find(Transporter.class, transporter2Delete.getId());
        
        if(transporter==null){
            resultObject.setMessage("Transporter with given Id not found!");
            resultObject.setObject("FAILURE");
            resultObject.setObjectClass(String.class);
            return resultObject;
        }
        transporter.setStatus(transporter.getStatus()&6);
        
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmm");
        Date deletionTIme=new Date();
        transporter.setName(transporter.getName()+ sdf.format(deletionTIme));
        em.merge(transporter);
        
        
        resultObject.setMessage("Transporter successfully sent to dustbin");
        resultObject.setObject(transporter);
        resultObject.setObjectClass(Transporter.class);
        return resultObject;
    }
    
    public ResultObject deleteTransporter(Integer transproterId){
        ResultObject resultObject=new ResultObject();
        Transporter transporter2Delete=em.find(Transporter.class, transproterId);
        if(transporter2Delete==null){
            resultObject.setMessage("Transporter with given Id not found!");
            resultObject.setObject("FAILURE");
            resultObject.setObjectClass(String.class);
            return resultObject;
        }
        
        Transporter transporter=em.find(Transporter.class, transporter2Delete.getId());
        transporter.setStatus(transporter.getStatus()&6);
        
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmm");
        Date deletionTIme=new Date();
        transporter.setName(transporter.getName()+ sdf.format(deletionTIme));
        em.merge(transporter);
        
        
        resultObject.setMessage("Transporter successfully sent to dustbin");
        resultObject.setObject(transporter);
        resultObject.setObjectClass(Transporter.class);
        return resultObject;
    }
    
}
