/*
* To change this license header, choose License Headers in Project Properties.
* To change this template file, choose Tools | Templates
* and open the template in the editor.
*/
package com.oltranz.IntercityTransport.beans;


import com.oltranz.IntercityTransport.entities.ItemOnSellingProfile;
import com.oltranz.IntercityTransport.entities.ProfileOnSellingDevice;
import com.oltranz.IntercityTransport.entities.SaleItem;
import com.oltranz.IntercityTransport.entities.Transporter;
import com.oltranz.IntercityTransport.entities.SellingProfile;
import com.oltranz.IntercityTransport.models.SellingProfileWithItemsModel;
import com.oltranz.IntercityTransport.models.ResultObject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import javax.ejb.Stateless;
import javax.ejb.LocalBean;
import java.util.List;
import javax.ejb.EJB;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
//import org.eclipse.persistence.config.HintValues;
//import org.eclipse.persistence.config.QueryHints;

/**
 *
 * @author manzi
 */
@Stateless
@LocalBean
public class SellingProfilesManager {
    @PersistenceContext(unitName = "IntercityTransportPU")
    private  EntityManager em;
    
    @EJB
            TransportersManager transportersManagerEJB;
    
    public ResultObject getSellingProfile(Integer profileId){
        ResultObject resultObject=new ResultObject();
        SellingProfile sellingProfile=em.find(SellingProfile.class,profileId);
        
        if(sellingProfile!=null){
            resultObject.setMessage("sellingProfile Well found and returned!");
            resultObject.setObject(sellingProfile);
            resultObject.setObjectClass(Transporter.class);
            return resultObject;
        }else{
            resultObject.setMessage("sellingProfile with given Id not found!");
            resultObject.setObject(null);
            resultObject.setObjectClass(String.class);
            return resultObject;
        }
    }
    
    public ResultObject createSellingProfileWithItems(SellingProfileWithItemsModel newProfile){
        SellingProfile profile=new SellingProfile();
        profile.setId(newProfile.getId());
        profile.setName(newProfile.getName());
        profile.setTransporterId(newProfile.getTransporterId());
        em.persist(profile);
        em.flush();
        
        newProfile.getItems().forEach( x-> {em.persist(x);});
        
        ResultObject resultObject= new ResultObject();
        resultObject.setObject(getSellingProfileWithItems(profile.getId()));
        resultObject.setObjectClass(SellingProfileWithItemsModel.class);
        
        return resultObject;
    }
    
    public ResultObject getSellingProfileWithItems(Integer profileId){
        ResultObject resultObject= new ResultObject();
        
        SellingProfileWithItemsModel profileWithItems=null;
        SellingProfile profile=em.find(SellingProfile.class,profileId);
        
        if(profile==null){
            resultObject.setObject(null);
            resultObject.setMessage("No selling profile with given id can be been found");
            resultObject.setObjectClass(SellingProfileWithItemsModel.class);
            return resultObject;
        }
        profileWithItems=new SellingProfileWithItemsModel();
        profileWithItems.setId(profileId);
        profileWithItems.setName(profile.getName());
        profileWithItems.setTransporterId(profile.getTransporterId());
        
        //then get the items
        Query query=em.createQuery("select i from SaleItem i left join ItemOnSellingProfile ip on i.id=ip.itemId where ip.profileId=:profileId");
        query.setParameter("profileId",profileId);
        
        profileWithItems.setItems(query.getResultList());
        
        resultObject.setObject(profileWithItems);
        resultObject.setMessage("Selling profile with given id well found");
        resultObject.setObjectClass(SellingProfileWithItemsModel.class);
        return resultObject;
    }    
   
    
    public ResultObject addItemToProfile(Integer itemId,Integer profileId ){
        ItemOnSellingProfile itemOnSellingProfile= new ItemOnSellingProfile();
        itemOnSellingProfile.setItemId(itemId);
        itemOnSellingProfile.setProfileId(profileId);
        em.persist(itemOnSellingProfile);
        
        ResultObject resultObject=new ResultObject();
        resultObject.setMessage("Item successfully added to profile");
        resultObject.setObject("SUCCESS");
        resultObject.setObjectClass(String.class);
        return null;
    }
    
    public ResultObject removeItemFromProfile(Integer itemId,Integer profileId ){
        ItemOnSellingProfile itemOnSellingProfile= new ItemOnSellingProfile();
        itemOnSellingProfile.setItemId(itemId);
        itemOnSellingProfile.setProfileId(profileId);
        em.remove(itemOnSellingProfile);
        
        ResultObject resultObject=new ResultObject();
        resultObject.setMessage("Item successfully removed from profile");
        resultObject.setObject("SUCCESS");
        resultObject.setObjectClass(String.class);
        return resultObject;
    }
    
    public ResultObject createSaleItem(SaleItem newItem){
        SaleItem saleItem=new SaleItem();
        saleItem.setName(newItem.getName());
        saleItem.setPrice(newItem.getPrice());
        saleItem.setTransporterId(newItem.getTransporterId());
        em.persist(saleItem);
        
        ResultObject resultObject=new ResultObject();
        resultObject.setMessage("Item successfully removed from profile");
        resultObject.setObject(saleItem);
        resultObject.setObjectClass(SaleItem.class);
        return resultObject;
    }
    
    public ResultObject updateSaleItem(SaleItem editItem){
        SaleItem saleItem=em.find(SaleItem.class, editItem.getId());
        saleItem.setName(editItem.getName());
        saleItem.setPrice(editItem.getPrice());
        saleItem.setTransporterId(editItem.getTransporterId());
        em.merge(saleItem);
        
        ResultObject resultObject=new ResultObject();
        resultObject.setMessage("Item successfully update");
        resultObject.setObject(saleItem);
        resultObject.setObjectClass(SaleItem.class);
        return resultObject;
    }
    
    public ResultObject createProfile(SellingProfile newProfile){
        SellingProfile profile=new SellingProfile();
        profile.setName(newProfile.getName());
        profile.setTransporterId(newProfile.getTransporterId());
        em.persist(newProfile);
        
        ResultObject resultObject=new ResultObject();
        resultObject.setMessage("Item successfully removed from profile");
        resultObject.setObject(newProfile);
        resultObject.setObjectClass(SellingProfile.class);
        return resultObject;
    }
    
    public ResultObject updateSellingProfile(SellingProfile editProfile){
        SellingProfile profile=em.find(SellingProfile.class, editProfile.getId());
        profile.setName(editProfile.getName());
        profile.setTransporterId(editProfile.getTransporterId());
        em.merge(profile);
        
        ResultObject resultObject=new ResultObject();
        resultObject.setMessage("Selling Profile successfully updated");
        resultObject.setObject(profile);
        resultObject.setObjectClass(SellingProfile.class);
        return resultObject;
    }
    
    public ResultObject deleteSellingProfile(SellingProfile profile2Delete){
        SellingProfile sellingProfile=em.find(SellingProfile.class, profile2Delete.getId());
        
        //set the first bit to
        sellingProfile.setStatus(sellingProfile.getStatus()&6);
        
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmm");
        Date deletionTIme=new Date();
        sellingProfile.setName(sellingProfile.getName()+ sdf.format(deletionTIme));
        em.merge(sellingProfile);
        
        ResultObject resultObject=new ResultObject();
        resultObject.setMessage("Selling Profile successfully sent to dustbin");
        resultObject.setObject(sellingProfile);
        resultObject.setObjectClass(Transporter.class);
        return resultObject;
    }
    
    public List<SaleItem> getSaleItemsList(Integer transporterId){
        Query query;
        if(transporterId>0){
            query=em.createQuery("select i from SaleItem i where i.transporterId=:transporterId ");
            query.setParameter("transporterId", transporterId);
        }
        else
            query=em.createQuery("select i from SaleItem i ");
        
        return (List<SaleItem>)query.getResultList();
    }
    
    public ResultObject getSellingProfilesList(Integer transporterId){
        ResultObject resultObject= new ResultObject();
        resultObject.setObject(transportersManagerEJB.getTransporter(transporterId));
        
        if(resultObject.getObject()==null)
            return resultObject;
        
        Query query;
        
        query=em.createQuery("select i from SellingProfile i where i.transporterId=:transporterId ");
        query.setParameter("transporterId", transporterId);
        
        List<SellingProfile> sellingProfileslist=(List<SellingProfile>)query.getResultList();
        
        
        resultObject.setObject(sellingProfileslist);
        resultObject.setObjectClass(ArrayList.class);
        
        if(sellingProfileslist.isEmpty()){
            resultObject.setMessage("There are no Selling profile for this transporter");
        }
        else{
            resultObject.setMessage(sellingProfileslist.size()+" Selling profiles for this transporter were found");
        }
               
        
        return resultObject;
    }
    
    
}
