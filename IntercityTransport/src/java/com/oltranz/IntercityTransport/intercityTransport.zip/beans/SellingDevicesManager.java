/*
* To change this license header, choose License Headers in Project Properties.
* To change this template file, choose Tools | Templates
* and open the template in the editor.
*/
package com.oltranz.IntercityTransport.beans;


import com.oltranz.IntercityTransport.entities.Bus;
import com.oltranz.IntercityTransport.entities.Contract;
import com.oltranz.IntercityTransport.entities.ProfileOnSellingDevice;
import com.oltranz.IntercityTransport.entities.SellingDevice;
import com.oltranz.IntercityTransport.models.ResultObject;
import com.oltranz.IntercityTransport.models.SellingProfileWithItemsModel;
import java.util.ArrayList;
import javax.ejb.Stateless;
import javax.ejb.LocalBean;
import java.util.List;
import javax.ejb.EJB;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
//import org.eclipse.persistence.config.HintValues;
//import org.eclipse.persistence.config.QueryHints;

/**
 *
 * @author manzi
 */
@Stateless
@LocalBean
public class SellingDevicesManager {
    @PersistenceContext(unitName = "IntercityTransportPU")
    private  EntityManager em;
    
    @EJB
            BusesManager BusesManagerEJB;
    @EJB
            SellingProfilesManager sellingProfilesManagerEJB;
    
    @EJB
            TransportersManager transportersManagerEJB;
    
    public ResultObject getSellingDevice(String imei){
        ResultObject resultObject=new ResultObject();
        SellingDevice SellingDevice=em.find(SellingDevice.class,imei);
        
        if(SellingDevice!=null){
            resultObject.setMessage("SellingDevice Well found and returned!");
            resultObject.setObject(SellingDevice);
            resultObject.setObjectClass(SellingDevice.class);
            return resultObject;
        }else{
            resultObject.setMessage("SellingDevice with given Id not found!");
            resultObject.setObject("NOT FOUND");
            resultObject.setObjectClass(String.class);
            return resultObject;
        }
    }
    
    public ResultObject getSellingDeviceProfile(Integer deviceId){
        ResultObject resultObject= new ResultObject();
        SellingProfileWithItemsModel profileWithItems=null;
        Query query=em.createQuery("select p from ProfileOnSellingDevice p where p.profileOnSellingDevicePK.deviceId=:deviceId");
        query.setParameter("deviceId", deviceId);
        ProfileOnSellingDevice profileOnSellingDevice=(ProfileOnSellingDevice)query.getSingleResult();
        
        if(profileOnSellingDevice==null){
            resultObject.setObject(null);
            resultObject.setMessage("No selling profile is currently assinged to this selling device");
            resultObject.setObjectClass(ProfileOnSellingDevice.class);
            return resultObject;
        }
        
        profileWithItems=(SellingProfileWithItemsModel) sellingProfilesManagerEJB.getSellingProfileWithItems(profileOnSellingDevice.getProfileOnSellingDevicePK().getProfileId()).getObject();
        resultObject.setObject(profileWithItems);
        resultObject.setMessage("Profile Well found and returned");
        resultObject.setObjectClass(ProfileOnSellingDevice.class);
        return resultObject;
        
    }
    
    public ResultObject createSellingDevice(SellingDevice newSellingDevice){
        SellingDevice sellingDevice=new SellingDevice();
        sellingDevice.setCurrentBusNumberPlate(newSellingDevice.getCurrentBusNumberPlate());
        sellingDevice.setDecr(newSellingDevice.getDecr());
        sellingDevice.setImei(newSellingDevice.getImei());
        sellingDevice.setTransporterId(newSellingDevice.getTransporterId());
        sellingDevice.setTypeId(newSellingDevice.getTypeId());
        em.persist(sellingDevice);
        
        ResultObject resultObject=new ResultObject();
        resultObject.setMessage("New sellingDevice successfully create");
        resultObject.setObject(sellingDevice);
        resultObject.setObjectClass(SellingDevice.class);
        return resultObject;
    }
    
    public ResultObject updateSellingDevice(SellingDevice editSellingDevice){
        SellingDevice sellingDevice=em.find(SellingDevice.class, editSellingDevice.getImei());
        sellingDevice.setCurrentBusNumberPlate(editSellingDevice.getCurrentBusNumberPlate());
        sellingDevice.setDecr(editSellingDevice.getDecr());
        sellingDevice.setImei(editSellingDevice.getImei());
        sellingDevice.setTransporterId(editSellingDevice.getTransporterId());
        sellingDevice.setTypeId(editSellingDevice.getTypeId());
        em.merge(sellingDevice);
        
        ResultObject resultObject=new ResultObject();
        resultObject.setMessage("SellingDevice successfully updated");
        resultObject.setObject(sellingDevice);
        resultObject.setObjectClass(SellingDevice.class);
        return resultObject;
    }
    
    public ResultObject attacheSellingDeviceToBus(String imei, String numberPlate){
        Bus bus;
        SellingDevice sellingDevice;
        ResultObject resultObject=getSellingDevice(imei);
        if(resultObject.getObject()==null)
            return resultObject;
        else
            sellingDevice=(SellingDevice)resultObject.getObject();
        
        resultObject=BusesManagerEJB.getBus(numberPlate);
        if(resultObject.getObject()==null)
            return resultObject;
        else
            bus=(Bus)resultObject.getObject();
        
        
        //A device belongs to transporter
        //A Bus belong or is attached to a contract
        //A device can only be used/added to a bus that belongs to the same transporter
        //or to a bus already attached to a contract of the same transporter
        
        if(bus.isTransporterOwned()){
            if(!bus.getOwnerId().equals(sellingDevice.getTransporterId())){
                resultObject.setObject(null);
                resultObject.setMessage("A selling device can not be used in a bus bellonging to a different Transporter");
                return resultObject;
            }
        }else{
            // get current contract to which this bus is attachd on
            
            Contract contract=(Contract)BusesManagerEJB.getBusCurrentContract(numberPlate).getObject();
            if(contract==null){
                resultObject.setObject(null);
                resultObject.setMessage("This bus does belong neither is it attached to any current contract with to the owner of this device");
                return resultObject;
            }else{
                if(!contract.getTransporterId().equals(sellingDevice.getTransporterId())){
                    resultObject.setObject(null);
                    resultObject.setMessage("This bus does belong neither is it attached to any current contract with to the owner of this device");
                    return resultObject;
                }
            }
        }
        sellingDevice.setCurrentBusNumberPlate(numberPlate);
        em.merge(sellingDevice);
        
        resultObject=getSellingDevice(sellingDevice.getImei());
        resultObject.setMessage("Device well attached to the bus with number plate "+numberPlate);
        return resultObject;
        
    }
    
    public ResultObject detachSellingDeviceFromCurrentBus(String imei){
        SellingDevice sellingDevice;
        ResultObject resultObject=getSellingDevice(imei);
        if(resultObject.getObject()==null)
            return resultObject;
        else
            sellingDevice=(SellingDevice)resultObject.getObject();
        
        if(sellingDevice.getCurrentBusNumberPlate().equals("") || sellingDevice.getCurrentBusNumberPlate()==null){
            resultObject.setMessage("This device is not attached to any bus!");
            return resultObject;
        }
        sellingDevice.setCurrentBusNumberPlate("");
        em.merge(sellingDevice);
        resultObject=getSellingDevice(imei);
        resultObject.setMessage("Device detached from bus and not attached to any!");
        return resultObject;
    }
    
    public ResultObject getTransporterSellingDevicesList(Integer transporterId){
        ResultObject resultObject= new ResultObject();
        resultObject.setObject(transportersManagerEJB.getTransporter(transporterId));
        
        if(resultObject.getObject()==null)
            return resultObject;
        
        Query query;
        
        query=em.createQuery("select d from SellingDevice d where d.transporterId=:transporterId ");
        query.setParameter("transporterId", transporterId);
        
        List<SellingDevice> sellingDeviceslist=(List<SellingDevice>)query.getResultList();
        
        
        resultObject.setObject(sellingDeviceslist);
        resultObject.setObjectClass(ArrayList.class);
        
        if(sellingDeviceslist.isEmpty()){
            resultObject.setMessage("There are no Selling Device for this transporter");
        }
        else{
            resultObject.setMessage(sellingDeviceslist.size()+" Selling Devices for this transporter were found");
        }
        return resultObject;
    }
    
    public ResultObject getAllSellingDevicesList(){
        ResultObject resultObject= new ResultObject();
        Query query;
        
        query=em.createQuery("select d from SellingDevice d  ");
        
        List<SellingDevice> sellingDevicesList=(List<SellingDevice>)query.getResultList();
        
        resultObject.setObject(sellingDevicesList);
        resultObject.setObjectClass(ArrayList.class);
        
        if(sellingDevicesList.isEmpty()){
            resultObject.setMessage("There are no selling Devices in the system");
        }
        else{
            resultObject.setMessage(sellingDevicesList.size()+" selling Devices  were found");
        }
               
        return resultObject;
        
    }            
    
    public ResultObject deleteSellingDevice(SellingDevice sellingDevice2Delete){
        SellingDevice sellingDevice=em.find(SellingDevice.class, sellingDevice2Delete.getImei());
        sellingDevice.setStatus(sellingDevice.getStatus()&6);
        
        em.merge(sellingDevice);
        
        ResultObject resultObject=new ResultObject();
        resultObject.setMessage("SellingDevice successfully sent to dustbin");
        resultObject.setObject(sellingDevice);
        resultObject.setObjectClass(SellingDevice.class);
        return resultObject;
    }
    
    
}
