/*
* To change this license header, choose License Headers in Project Properties.
* To change this template file, choose Tools | Templates
* and open the template in the editor.
*/
package com.oltranz.IntercityTransport.beans;


import com.oltranz.IntercityTransport.entities.Service;
import com.oltranz.IntercityTransport.entities.ServiceProvider;
import com.oltranz.IntercityTransport.models.ResultObject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.ejb.Stateless;
import javax.ejb.LocalBean;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
//import org.eclipse.persistence.config.HintValues;
//import org.eclipse.persistence.config.QueryHints;

/**
 *
 * @author manzi
 */
@Stateless
@LocalBean
public class ServicesProvidersManager {
    @PersistenceContext(unitName = "IntercityTransportPU")
    private  EntityManager em;
    
    public ResultObject getServiceProvider(Integer serviceProviderId){
        ResultObject resultObject=new ResultObject();
        ServiceProvider serviceProvider=em.find(ServiceProvider.class,serviceProviderId);
        
        if(serviceProvider!=null){
            resultObject.setMessage("ServiceProvider Well found and returned!");
            resultObject.setObject(serviceProvider);
            resultObject.setObjectClass(ServiceProvider.class);
            return resultObject;
        }else{
            resultObject.setMessage("ServiceProvider with given Id not found!");
            resultObject.setObject("NOT FOUND");
            resultObject.setObjectClass(String.class);
            return resultObject;
        }
    }
    
    public ResultObject createServiceProvider(ServiceProvider newServiceProvider){
        ResultObject resultObject=new ResultObject();
        ServiceProvider serviceProvider=new ServiceProvider();
        //confirm that is the new service is different from the existing, the new service does exists
        
        if(em.find(Service.class, newServiceProvider.getServiceId())==null){
            resultObject.setMessage("The Service specified for this service provider cannot be found !");
            resultObject.setObject("FAILURE");
            resultObject.setObjectClass(String.class);
            return resultObject;
        }
        
        serviceProvider.setName(newServiceProvider.getName());
        serviceProvider.setServiceId(newServiceProvider.getServiceId());
        serviceProvider.setDescr(newServiceProvider.getDescr());
        em.persist(serviceProvider);
        
        resultObject.setMessage("New serviceProvider successfully create");
        resultObject.setObject(serviceProvider);
        resultObject.setObjectClass(ServiceProvider.class);
        return resultObject;
    }
    
    public ResultObject updateServiceProvider(ServiceProvider editServiceProvider){
        ResultObject resultObject=new ResultObject();
        ServiceProvider serviceProvider=em.find(ServiceProvider.class, editServiceProvider.getId());
        
        //confirm that is the new service is different from the existing, the new service does exists
        if(serviceProvider.getServiceId()==null)
            serviceProvider.setServiceId(1);
        
        if( editServiceProvider.getServiceId()==null)
            editServiceProvider.setServiceId(1);
        
        if(!serviceProvider.getServiceId().equals(editServiceProvider.getServiceId())){
            if(em.find(Service.class, editServiceProvider.getServiceId())!=null){
                resultObject.setMessage("New Service cannot be found !");
                resultObject.setObject("FAILURE");
                resultObject.setObjectClass(String.class);
                return resultObject;
            }
        }
        
        serviceProvider.setName(editServiceProvider.getName());
        serviceProvider.setServiceId(editServiceProvider.getServiceId());
        serviceProvider.setDescr(editServiceProvider.getDescr());
        em.merge(serviceProvider);
        
        
        resultObject.setMessage("ServiceProvider successfully updated");
        resultObject.setObject(serviceProvider);
        resultObject.setObjectClass(ServiceProvider.class);
        return resultObject;
    }
    
    public ResultObject getServicesProvidersList(){
      ResultObject resultObject=new ResultObject();
        Query query;
        
        query=em.createQuery("select sp from ServiceProvider sp");
        
        
        List<ServiceProvider> spList=(List<ServiceProvider>)query.getResultList();
        if(spList.isEmpty())
            resultObject.setMessage("No Service provider ");
        else
            resultObject.setMessage("Service Providers List well returned");
        resultObject.setObject(spList);
        resultObject.setObjectClass(ArrayList.class);
        return resultObject;
    }
    
    public ResultObject getServicesProvidersList(Integer transporterId){
        ResultObject resultObject=new ResultObject();
        Query query;
        
        query=em.createQuery("select sp from ServiceProvider sp join Contract c on sp.id=c.serviceProviderId where c.transporterId=:transporterId ");
        query.setParameter("transporterId", transporterId);
        
        List<ServiceProvider> spList=(List<ServiceProvider>)query.getResultList();
        if(spList.isEmpty())
            resultObject.setMessage("No Service provider for this transporter");
        else
            resultObject.setMessage("Service Providers List well returned");
        resultObject.setObject(spList);
        resultObject.setObjectClass(ArrayList.class);
        return resultObject;
    }
    
    public ResultObject deleteServiceProvider(Integer serviceProvider2DeleteId){
        ResultObject resultObject=new ResultObject();
        ServiceProvider serviceProvider=em.find(ServiceProvider.class, serviceProvider2DeleteId);
        
        if(serviceProvider!=null){
            resultObject.setMessage("No service provider with provided id is found!");
            resultObject.setObject("FAILURE");
            resultObject.setObjectClass(String.class);
            return resultObject;
        }
        
        serviceProvider.setStatus(serviceProvider.getStatus()&6);
        
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmm");
        Date deletionTIme=new Date();
        serviceProvider.setName(serviceProvider.getName()+ sdf.format(deletionTIme));
        em.merge(serviceProvider);
        
        
        resultObject.setMessage("ServiceProvider successfully sent to dustbin");
        resultObject.setObject(serviceProvider);
        resultObject.setObjectClass(ServiceProvider.class);
        return resultObject;
    }
    
    public ResultObject deleteServiceProvider(ServiceProvider serviceProvider2Delete){
        ServiceProvider serviceProvider=em.find(ServiceProvider.class, serviceProvider2Delete.getId());
        ResultObject resultObject=new ResultObject();
        if(serviceProvider!=null){
            resultObject.setMessage("No service provider with provided id is found!");
            resultObject.setObject("FAILURE");
            resultObject.setObjectClass(String.class);
            return resultObject;
        }
        
        serviceProvider.setStatus(serviceProvider.getStatus()&6);
        
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmm");
        Date deletionTIme=new Date();
        serviceProvider.setName(serviceProvider.getName()+ sdf.format(deletionTIme));
        em.merge(serviceProvider);
        
        
        resultObject.setMessage("ServiceProvider successfully sent to dustbin");
        resultObject.setObject(serviceProvider);
        resultObject.setObjectClass(ServiceProvider.class);
        return resultObject;
    }
    
}
