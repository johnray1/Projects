/*
* To change this license header, choose License Headers in Project Properties.
* To change this template file, choose Tools | Templates
* and open the template in the editor.
*/
package com.oltranz.IntercityTransport.beans;


import com.oltranz.IntercityTransport.entities.User;
import com.oltranz.IntercityTransport.entities.Wallet;
import com.oltranz.IntercityTransport.models.ResultObject;
import javax.ejb.Stateless;
import javax.ejb.LocalBean;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
//import org.eclipse.persistence.config.HintValues;
//import org.eclipse.persistence.config.QueryHints;

/**
 *
 * @author manzi
 */
@Stateless
@LocalBean
public class WalletsManager {
    @PersistenceContext(unitName = "IntercityTransportPU")
    private  EntityManager em;
    
    public ResultObject getWallet(Integer walletId){
        ResultObject resultObject=new ResultObject();
        Wallet wallet=em.find(Wallet.class,walletId);
        
        if(wallet==null){
            resultObject.setMessage("Wallet with given Id not found!");
            resultObject.setObject(null);
            resultObject.setObjectClass(Wallet.class);
            return resultObject;
        }else{
            resultObject.setMessage("Wallet well found!");
            resultObject.setObject(wallet);
            resultObject.setObjectClass(Wallet.class);
            return resultObject;
        }
    }
    
    public ResultObject createWallet(Wallet newWallet){
        ResultObject resultObject=new ResultObject();
        String ownerTypeName="";        
        try{
            
            //Owner's Id and owner type id can never null;
            if(newWallet.getOwnerId()==null || newWallet.getTypeId()==null){
                resultObject.setMessage("Neither OwnerId nor typeId can be null");
                resultObject.setObject(null);
                resultObject.setObjectClass(Wallet.class);
                return resultObject;
            }
            
            switch(newWallet.getTypeId()){
                case 1:
                    if(em.find(User.class, newWallet.getOwnerId())==null){
                        resultObject.setMessage("[type 1: passenger],Owner Passenger user (with id:"+newWallet.getOwnerId()+")  cannot be found");
                        resultObject.setObject(null);
                        resultObject.setObjectClass(Wallet.class);
                        return resultObject;
                    }
                    ownerTypeName="Passenger";
                    break;
                case 2:
                    if(em.find(User.class, newWallet.getOwnerId())==null){
                        resultObject.setMessage("[type 2: transporter],Owner Transporter (with id:"+newWallet.getOwnerId()+")  cannot be found");
                        resultObject.setObject(null);
                        resultObject.setObjectClass(Wallet.class);
                        return resultObject;
                    }
                    ownerTypeName="Transporter";
                    break;
                    
                case 3:
                    if(em.find(User.class, newWallet.getOwnerId())==null){
                        resultObject.setMessage("[type 3: Service Provider],Owner Service Provider (with id:"+newWallet.getOwnerId()+")  cannot be found");
                        resultObject.setObject(null);
                        resultObject.setObjectClass(Wallet.class);
                        return resultObject;
                    }
                    ownerTypeName="Service Provider";
                    break;
                    
                default:
                    ownerTypeName="Unknown type";
                    resultObject.setMessage("[type "+newWallet.getTypeId()+": Invalid wallet type");
                    resultObject.setObject(null);
                    resultObject.setObjectClass(Wallet.class);
                    return resultObject;
            }
            
            //check to see if no other wallet is attached to this owner
            Query query=em.createQuery("select w from Wallet w where w.ownerId=:ownerId and w.typeId=:typeId");
            query.setParameter("ownerId", newWallet.getOwnerId());
            query.setParameter("typeId", newWallet.getTypeId());
            
            if(query.getSingleResult()!=null){
                resultObject.setMessage("[type"+newWallet.getTypeId()+":"+ownerTypeName+"; This "+ownerTypeName+" has alreadygot another wallet");
                resultObject.setObject(null);
                resultObject.setObjectClass(Wallet.class);
                return resultObject;
            }
            
            em.persist(newWallet);
            resultObject.setMessage("Wallet for this "+ownerTypeName+" well created");
            resultObject.setObject(newWallet);
            resultObject.setObjectClass(Wallet.class);
            return resultObject;
        }
        catch(Exception e){
            resultObject.setMessage("Exception duting creation of a "+ownerTypeName+" wallet. Error message:"+e.getMessage());
            resultObject.setObject(null);
            resultObject.setObjectClass(Wallet.class);
            return resultObject;
        }
    }
    
   
  
    
}
