/*
* To change this license header, choose License Headers in Project Properties.
* To change this template file, choose Tools | Templates
* and open the template in the editor.
*/
package com.oltranz.IntercityTransport.beans;


import com.oltranz.IntercityTransport.entities.Contract;
import com.oltranz.IntercityTransport.entities.ServiceProvider;
import com.oltranz.IntercityTransport.entities.Transporter;
import com.oltranz.IntercityTransport.models.ContractModel;
import com.oltranz.IntercityTransport.models.ResultObject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import javax.ejb.Stateless;
import javax.ejb.LocalBean;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
//import org.eclipse.persistence.config.HintValues;
//import org.eclipse.persistence.config.QueryHints;

/**
 *
 * @author manzi
 */
@Stateless
@LocalBean
public class ContractsManager {
    @PersistenceContext(unitName = "IntercityTransportPU")
    private  EntityManager em;
    
    
    public ContractModel getContractModel(Contract contract){
       
         SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        
        if(contract!=null){
            ContractModel contractModel=new ContractModel();
            contractModel.setAmount(""+contract.getAmount());
            contractModel.setDescr(contract.getDescr());
            contractModel.setName(contract.getName());
            contractModel.setEndDate(sdf.format(contract.getEndDate()));
            contractModel.setParcentage(""+contract.getParcentage());
            contractModel.setPaymentPeriod(contract.getPaymentPeriod());
            contractModel.setServiceProviderId(contract.getServiceProviderId());
            contractModel.setStartDate(sdf.format(contract.getStartDate()));
            contractModel.setTransporterId(contract.getTransporterId());
            contractModel.setWithPeriodicPayment(contract.isWithPeriodicPayment());
            return contractModel;
        }else{
            return null;
        }
    }
    
    public ResultObject getContract(Integer contractId){
        ResultObject resultObject=new ResultObject();
        Contract contract=em.find(Contract.class,contractId);
        
         SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        
        if(contract!=null){
            ContractModel contractModel=getContractModel(contract);
           
            resultObject.setMessage("Contract Well found and returned!");
            resultObject.setObject(contractModel);
            resultObject.setObjectClass(ContractModel.class);
            return resultObject;
        }else{
            resultObject.setMessage("Contract with given Id not found!");
            resultObject.setObject("NOT FOUND");
            resultObject.setObjectClass(String.class);
            return resultObject;
        }
    }
    
    public ResultObject createContract(ContractModel newContract){
        ResultObject resultObject=new ResultObject();
        try{
            Contract contract=new Contract();
            
            //confirm that is the new service provider does exist in the system database
            
            if(em.find(ServiceProvider.class, newContract.getServiceProviderId())==null){
                resultObject.setMessage("The specified service provider for this contract cannot be found !");
                resultObject.setObject("FAILURE");
                resultObject.setObjectClass(String.class);
                return resultObject;
            }
            
            if(em.find(Transporter.class, newContract.getTransporterId())==null){
                resultObject.setMessage("The specified Contracting transporter for this contract cannot be found !");
                resultObject.setObject("FAILURE");
                resultObject.setObjectClass(String.class);
                return resultObject;
            }
            
            String dateFormat="yyyy-MM-dd";
            
            contract.setAmount(Double.parseDouble(newContract.getAmount()));
            contract.setDescr(newContract.getDescr());
            contract.setName(newContract.getName());
            contract.setEndDate(newContract.getEndDate(),dateFormat);
            contract.setParcentage(Double.parseDouble(newContract.getParcentage()));
            contract.setPaymentPeriod(newContract.getPaymentPeriod());
            contract.setServiceProviderId(newContract.getServiceProviderId());
            contract.setStartDate(newContract.getStartDate(),dateFormat);
            contract.setTransporterId(newContract.getTransporterId());
            contract.setWithPeriodicPayment(newContract.isWithPeriodicPayment());
            
            em.persist(contract);
            
            resultObject.setMessage("New contract successfully created");
            resultObject.setObject(getContractModel(contract));
            resultObject.setObjectClass(ContractModel.class);
            return resultObject;
        }
        catch(Exception e){
            resultObject.setMessage("Exception duting creation successfully create");
            resultObject.setObject(e.getMessage());
            resultObject.setObjectClass(String.class);
            return resultObject;
        }
    }
    
    public ResultObject updateContract(ContractModel editContract){
        ResultObject resultObject=new ResultObject();
        Contract contract=em.find(Contract.class, editContract.getId());
        
        //confirm that is the new service is different from the existing, the new service does exists
        if(!contract.getServiceProviderId().equals(editContract.getServiceProviderId())){
            if(em.find(ServiceProvider.class, editContract.getServiceProviderId())!=null){
                resultObject.setMessage("The newly specified service provider for this contract cannot be found !");
                resultObject.setObject("FAILURE");
                resultObject.setObjectClass(String.class);
                return resultObject;
            }
        }
        
        if(!contract.getTransporterId().equals(editContract.getTransporterId())){
            if(em.find(Transporter.class, editContract.getTransporterId())!=null){
                resultObject.setMessage("The newly specified Contracting transporter for this contract cannot be found !");
                resultObject.setObject("FAILURE");
                resultObject.setObjectClass(String.class);
                return resultObject;
            }
        }
        
        String dateFormat="yyyyMMdd";
        
        contract.setAmount(Double.parseDouble(editContract.getAmount()));
        contract.setDescr(editContract.getDescr());
        contract.setName(editContract.getName());
        contract.setEndDate(editContract.getEndDate(),dateFormat);
        contract.setParcentage(Double.parseDouble(editContract.getParcentage()));
        contract.setPaymentPeriod(editContract.getPaymentPeriod());
        contract.setServiceProviderId(editContract.getServiceProviderId());
        contract.setStartDate(editContract.getStartDate(),dateFormat);
        contract.setTransporterId(editContract.getTransporterId());
        contract.setWithPeriodicPayment(editContract.isWithPeriodicPayment());
        em.merge(contract);
        
        ContractModel contractModel=getContractModel(contract);
        resultObject.setMessage("Contract successfully updated");
        resultObject.setObject(contractModel);
        resultObject.setObjectClass(ContractModel.class);
        return resultObject;
    }
    
    public ResultObject getContractsList(){
        Query query;
        ResultObject resultObject=new ResultObject();
        
        query=em.createQuery("select t from Contract t ");
        
        resultObject.setMessage("Contracts List well returned");
        resultObject.setObject(query.getResultList());
        resultObject.setObjectClass(ArrayList.class);
        return resultObject;
    }
    
    public ResultObject getContractsList(Integer transporterId){
        ResultObject resultObject=new ResultObject();
        Query query;
        
        query=em.createQuery("select c from Contract c where c.transporterId=:transporterId ");
        query.setParameter("transporterId", transporterId);
        
        List<Contract> spList=(List<Contract>)query.getResultList();
        if(spList.isEmpty())
            resultObject.setMessage("No Contract with service providers for this transporter");
        else
            resultObject.setMessage("List of Contracts with Service Provider List well returned");
        resultObject.setObject(spList);
        resultObject.setObjectClass(ArrayList.class);
        return resultObject;
    }
    
    public ResultObject deleteContract(Contract contract2Delete){
        Contract contract=em.find(Contract.class, contract2Delete.getId());
        contract.setStatus(contract.getStatus()&6);
        
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmm");
        Date deletionTIme=new Date();
        contract.setName(contract.getName()+ sdf.format(deletionTIme));
        em.merge(contract);
        
        ResultObject resultObject=new ResultObject();
        resultObject.setMessage("Contract successfully sent to dustbin");
        resultObject.setObject(contract);
        resultObject.setObjectClass(Contract.class);
        return resultObject;
    }
    
    public ResultObject deleteContract(Integer contract2DeleteId){
        Contract contract=em.find(Contract.class, contract2DeleteId);
        contract.setStatus(contract.getStatus()&6);
        
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmm");
        Date deletionTIme=new Date();
        contract.setName(contract.getName()+ sdf.format(deletionTIme));
        em.merge(contract);
        
        ResultObject resultObject=new ResultObject();
        resultObject.setMessage("Contract successfully sent to dustbin");
        resultObject.setObject(contract);
        resultObject.setObjectClass(Contract.class);
        return resultObject;
    }
    
}
