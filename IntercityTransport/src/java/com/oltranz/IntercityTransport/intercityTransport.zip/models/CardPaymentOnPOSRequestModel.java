/*
* To change this license header, choose License Headers in Project Properties.
* To change this template file, choose Tools | Templates
* and open the template in the editor.
*/
package com.oltranz.IntercityTransport.models;

import java.io.Serializable;
import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.map.annotate.JsonRootName;

/**
 *
 * @author ismaelnzamutuma
 */
@JsonRootName("DeviceSaleModel")
public class CardPaymentOnPOSRequestModel implements Serializable {
    private String cardId;
    @JsonProperty("devId")
    private String deviceId;
    private String itemId;
    private String quantity;
    private String totalAmount;
    private String profileId;
    
    /**
     * @return the cardId
     */
    public String getCardId() {
        return cardId;
    }
    
    /**
     * @param cardId the cardId to set
     */
    public void setCardId(String cardId) {
        this.cardId = cardId;
    }
    
    /**
     * @return the deviceId
     */
    public String getDeviceId() {
        return deviceId;
    }
    
    /**
     * @param deviceId the deviceId to set
     */
    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }
    
    /**
     * @return the itemId
     */
    public String getItemId() {
        return itemId;
    }
    
    /**
     * @param itemId the itemId to set
     */
    public void setItemId(String itemId) {
        this.itemId = itemId;
    }
    
    /**
     * @return the quantity
     */
    public String getQuantity() {
        return quantity;
    }
    
    /**
     * @param quantity the quantity to set
     */
    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }
    
    /**
     * @return the totalAmount
     */
    public String getTotalAmount() {
        return totalAmount;
    }
    
    /**
     * @param totalAmount the totalAmount to set
     */
    public void setTotalAmount(String totalAmount) {
        this.totalAmount = totalAmount;
    }
    
    /**
     * @return the profileId
     */
    public String getProfileId() {
        return profileId;
    }
    
    /**
     * @param profileId the profileId to set
     */
    public void setProfileId(String profileId) {
        this.profileId = profileId;
    }
    
}
