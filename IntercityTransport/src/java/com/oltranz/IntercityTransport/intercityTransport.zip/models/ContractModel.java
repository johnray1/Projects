/*
* To change this license header, choose License Headers in Project Properties.
* To change this template file, choose Tools | Templates
* and open the template in the editor.
*/
package com.oltranz.IntercityTransport.models;

/**
 *
 * @author manzi
 */


public class ContractModel {

    private Integer id;   
    private Integer transporterId;
    private Integer serviceProviderId;
    private boolean withPeriodicPayment;
    private String name;
    private String paymentPeriod;
    private String amount;
    private String parcentage;
    private String startDate;
    private String endDate;
    private String descr;

    /**
     * @return the id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * @return the transporterId
     */
    public Integer getTransporterId() {
        return transporterId;
    }

    /**
     * @param transporterId the transporterId to set
     */
    public void setTransporterId(Integer transporterId) {
        this.transporterId = transporterId;
    }

    /**
     * @return the serviceProviderId
     */
    public Integer getServiceProviderId() {
        return serviceProviderId;
    }

    /**
     * @param serviceProviderId the serviceProviderId to set
     */
    public void setServiceProviderId(Integer serviceProviderId) {
        this.serviceProviderId = serviceProviderId;
    }

    /**
     * @return the withPeriodicPayment
     */
    public boolean isWithPeriodicPayment() {
        return withPeriodicPayment;
    }

    /**
     * @param withPeriodicPayment the withPeriodicPayment to set
     */
    public void setWithPeriodicPayment(boolean withPeriodicPayment) {
        this.withPeriodicPayment = withPeriodicPayment;
    }

    /**
     * @return the paymentPeriod
     */
    public String getPaymentPeriod() {
        return paymentPeriod;
    }

    /**
     * @param paymentPeriod the paymentPeriod to set
     */
    public void setPaymentPeriod(String paymentPeriod) {
        this.paymentPeriod = paymentPeriod;
    }

    /**
     * @return the amount
     */
    public String getAmount() {
        return amount;
    }

    /**
     * @param amount the amount to set
     */
    public void setAmount(String amount) {
        this.amount = amount;
    }

    /**
     * @return the parcentage
     */
    public String getParcentage() {
        return parcentage;
    }

    /**
     * @param parcentage the parcentage to set
     */
    public void setParcentage(String parcentage) {
        this.parcentage = parcentage;
    }

    /**
     * @return the startDate
     */
    public String getStartDate() {
        return startDate;
    }

    /**
     * @param startDate the startDate to set
     */
    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    /**
     * @return the endDate
     */
    public String getEndDate() {
        return endDate;
    }

    /**
     * @param endDate the endDate to set
     */
    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    /**
     * @return the descr
     */
    public String getDescr() {
        return descr;
    }

    /**
     * @param descr the descr to set
     */
    public void setDescr(String descr) {
        this.descr = descr;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }
    
   
}
