/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.oltranz.IntercityTransport.models;

import com.oltranz.IntercityTransport.entities.Trip;
import java.util.List;

/**
 *
 * @author manzi
 */
public class deviceProfileModel {
    private String profileName;
    private Integer profileId;
    private List<Trip> items;

    /**
     * @return the profileName
     */
    public String getProfileName() {
        return profileName;
    }

    /**
     * @param profileName the profileName to set
     */
    public void setProfileName(String profileName) {
        this.profileName = profileName;
    }

    /**
     * @return the profileId
     */
    public Integer getProfileId() {
        return profileId;
    }

    /**
     * @param profileId the profileId to set
     */
    public void setProfileId(Integer profileId) {
        this.profileId = profileId;
    }

    /**
     * @return the items
     */
    public List<Trip> getItems() {
        return items;
    }

    /**
     * @param items the items to set
     */
    public void setItems(List<Trip> items) {
        this.items = items;
    }
    
}
