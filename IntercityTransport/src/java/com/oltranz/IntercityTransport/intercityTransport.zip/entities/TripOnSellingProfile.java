/*
* To change this license header, choose License Headers in Project Properties.
* To change this template file, choose Tools | Templates
* and open the template in the editor.
*/
package com.oltranz.IntercityTransport.entities;


import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

/**
 *
 * @author manzi
 */
@Entity
@Table(name = "trips_on_sellingprofiles",uniqueConstraints = {
    @UniqueConstraint(columnNames = {"trip_id","profile_id"})})
public class TripOnSellingProfile implements Serializable {
    private static final long serialVersionUID = 1L;
    
    /**
     * @return the serialVersionUID
     */
    public static long getSerialVersionUID() {
        return serialVersionUID;
    }
    @Id
    @Column(name = "id")
    private Integer id;
    
    @Column(name = "Name", length = 100)
    private String Name;
    
    @Column(name = "trip_id")
    private Integer tripId;
    
    @Column(name = "profile_id")
    private Integer profileId;
    
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (getId() != null ? getId().hashCode() : 0);
        return hash;
    }
    
    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof SellingProfile)) {
            return false;
        }
        SellingProfile other = (SellingProfile) object;
        if ((this.getId() == null && other.getId() != null) || (this.getId() != null && !this.id.equals(other.getId()))) {
            return false;
        }
        return true;
    }
    
    @Override
    public String toString() {
        return "com.oltranz.IntercityTransport.TripOnSellingProfile[ id=" + getId() + " ]";
    }
    
    /**
     * @return the id
     */
    public Integer getId() {
        return id;
    }
    
    /**
     * @param id the id to set
     */
    public void setId(Integer id) {
        this.id = id;
    }
    
    /**
     * @return the Name
     */
    public String getName() {
        return Name;
    }
    
    /**
     * @param Name the Name to set
     */
    public void setName(String Name) {
        this.Name = Name;
    }
    
    /**
     * @return the profileId
     */
    public Integer getTransporterId() {
        return getProfileId();
    }
    
    /**
     * @param profileId the profileId to set
     */
    public void setTransporterId(Integer profileId) {
        this.setProfileId(profileId);
    }

    /**
     * @return the tripId
     */
    public Integer getTripId() {
        return tripId;
    }

    /**
     * @param tripId the tripId to set
     */
    public void setTripId(Integer tripId) {
        this.tripId = tripId;
    }

    /**
     * @return the profileId
     */
    public Integer getProfileId() {
        return profileId;
    }

    /**
     * @param profileId the profileId to set
     */
    public void setProfileId(Integer profileId) {
        this.profileId = profileId;
    }
    
    
}
