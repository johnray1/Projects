/*
* To change this license header, choose License Headers in Project Properties.
* To change this template file, choose Tools | Templates
* and open the template in the editor.
*/
package com.oltranz.IntercityTransport.entities;


import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

/**
 *
 * @author ismaelnzamutuma
 */
@Embeddable
public class TransporterTripPK implements Serializable {
    
    @Basic(optional = false)
    @NotNull
    @Column(name = "transporter_id", nullable = false)
    private int transporterId;
    
    @Basic(optional = false)
    @NotNull
    @Column(name = "route_id", nullable = false)
    private int routeId;
    
    @Basic(optional = false)
    @NotNull
    @Column(name = "departure_location_id", nullable = false)
    private int departureLocationId;
    
    @Basic(optional = false)
    @NotNull
    @Column(name = "destination_location_id", nullable = false)
    private int destinationLocationId;
    
    
    
    public TransporterTripPK() {
    }
    
    public TransporterTripPK(Integer transporterId,Integer routeId, Integer departureLocationId,Integer destinationLocationId) {
        this.transporterId=transporterId;
        this.routeId = routeId;
        this.departureLocationId = departureLocationId;
        this.destinationLocationId=destinationLocationId;
    }
    
    
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) getTransporterId();
        hash += (int) getRouteId();
        hash += (int) getDepartureLocationId();
        hash += (int) getDestinationLocationId();
        return hash;
    }
    
    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof TripPK)) {
            return false;
        }
        TransporterTripPK other = (TransporterTripPK) object;
          if (this.getTransporterId() != other.getTransporterId()) {
            return false;
        }
        if (this.getRouteId() != other.getRouteId()) {
            return false;
        }
        if (this.getDepartureLocationId() != other.getDepartureLocationId()) {
            return false;
        }
        if (this.getDestinationLocationId() != other.getDestinationLocationId()) {
            return false;
        }
        return true;
    }
    
    @Override
    public String toString() {
        return "com.oltranz.IntercityTransport.Entities.Trip[ TransporterId=" + getTransporterId() + "RouteId=" + getRouteId() + ", DepartureLocationId=" + getDepartureLocationId() + ", DestinationLocationId=" + getDestinationLocationId() +" ]";
    }
    
    /**
     * @return the routeId
     */
    public int getRouteId() {
        return routeId;
    }
    
    /**
     * @param routeId the routeId to set
     */
    public void setRouteId(int routeId) {
        this.routeId = routeId;
    }
    
    /**
     * @return the departureLocationId
     */
    public int getDepartureLocationId() {
        return departureLocationId;
    }
    
    /**
     * @param departureLocationId the departureLocationId to set
     */
    public void setDepartureLocationId(int departureLocationId) {
        this.departureLocationId = departureLocationId;
    }
    
    /**
     * @return the destinationLocationId
     */
    public int getDestinationLocationId() {
        return destinationLocationId;
    }
    
    /**
     * @param destinationLocationId the destinationLocationId to set
     */
    public void setDestinationLocationId(int destinationLocationId) {
        this.destinationLocationId = destinationLocationId;
    }

    /**
     * @return the transporterId
     */
    public int getTransporterId() {
        return transporterId;
    }

    /**
     * @param transporterId the transporterId to set
     */
    public void setTransporterId(int transporterId) {
        this.transporterId = transporterId;
    }
    
    
}
