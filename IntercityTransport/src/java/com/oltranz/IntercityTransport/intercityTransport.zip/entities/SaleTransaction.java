/*
* To change this license header, choose License Headers in Project Properties.
* To change this template file, choose Tools | Templates
* and open the template in the editor.
*/
package com.oltranz.IntercityTransport.entities;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author manzi
 */
@Entity
@Table(name = "sales_transactions")
@XmlRootElement
public class SaleTransaction implements Serializable {
    private static final long serialVersionUID = 1L;
    
    /**
     * @return the serialVersionUID
     */
    public static long getSerialVersionUID() {
        return serialVersionUID;
    }
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    
    @Column(name = "id")
    private Long id;
    
    @Column(name = "device_imei")
    private String walletImei;
    
    @Column(name = "card_id")
    private String cardId;
    
    @Column(name = "Selling_profile_Id")
    private String sellingProfileId;
    
    @Column(name = "transporter_id")
    private String transporterId;
    
    @Column(name = "trip_id")
    private Integer trip_id;
    
      
    @Column(name = "unit_price")
    private Double unitPrice;
    
    @Column(name = "qty")
    private Integer qty;
    
    @Column(name = "total_price")
    private Double totalPrice;
    
    @Column(name = "transporter_wallet_id")
    private Integer transporterWalletId;
    
    @Column(name = "transporter_wallet_prev_balance")
    private Double transporterWalletPrevBalance;
    
    @Column(name = "transporter_wallet_new_balance")
    private Double transporterWalletNewBalance;
    
    @Column(name = "passanger_wallet_id")
    private Integer passangerWalletId;
    
    @Column(name = "passanger_wallet_prev_balance")
    private Double passangerWalletPrevBalance;
    
    @Column(name = "passanger_wallet_new_balance")
    private Double passangerWalletNewBalance;
    
    @Column(name = "date_time", nullable = false)
    @Temporal(TemporalType.DATE)
    private Date dateTime;
    
  
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (getId() != null ? getId().hashCode() : 0);
        return hash;
    }
    
    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof SaleTransaction)) {
            return false;
        }
        SaleTransaction other = (SaleTransaction) object;
        if ((this.getId() == null && other.getId() != null) || (this.getId() != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }
    
    @Override
    public String toString() {
        return "com.oltranz.IntercityTransport.Entities.walletTransaction[ id=" + getId() + " ]";
    }

    /**
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return the walletImei
     */
    public String getWalletImei() {
        return walletImei;
    }

    /**
     * @param walletImei the walletImei to set
     */
    public void setWalletImei(String walletImei) {
        this.walletImei = walletImei;
    }

    /**
     * @return the cardId
     */
    public String getCardId() {
        return cardId;
    }

    /**
     * @param cardId the cardId to set
     */
    public void setCardId(String cardId) {
        this.cardId = cardId;
    }

    /**
     * @return the sellingProfileId
     */
    public String getSellingProfileId() {
        return sellingProfileId;
    }

    /**
     * @param sellingProfileId the sellingProfileId to set
     */
    public void setSellingProfileId(String sellingProfileId) {
        this.sellingProfileId = sellingProfileId;
    }

    /**
     * @return the transporterId
     */
    public String getTransporterId() {
        return transporterId;
    }

    /**
     * @param transporterId the transporterId to set
     */
    public void setTransporterId(String transporterId) {
        this.transporterId = transporterId;
    }

    /**
     * @return the trip_id
     */
    public Integer getTrip_id() {
        return trip_id;
    }

    /**
     * @param trip_id the trip_id to set
     */
    public void setTrip_id(Integer trip_id) {
        this.trip_id = trip_id;
    }

    /**
     * @return the unitPrice
     */
    public Double getUnitPrice() {
        return unitPrice;
    }

    /**
     * @param unitPrice the unitPrice to set
     */
    public void setUnitPrice(Double unitPrice) {
        this.unitPrice = unitPrice;
    }

    /**
     * @return the qty
     */
    public Integer getQty() {
        return qty;
    }

    /**
     * @param qty the qty to set
     */
    public void setQty(Integer qty) {
        this.qty = qty;
    }

    /**
     * @return the totalPrice
     */
    public Double getTotalPrice() {
        return totalPrice;
    }

    /**
     * @param totalPrice the totalPrice to set
     */
    public void setTotalPrice(Double totalPrice) {
        this.totalPrice = totalPrice;
    }

    
    /**
     * @return the transporterWalletPrevBalance
     */
    public Double getTransporterWalletPrevBalance() {
        return transporterWalletPrevBalance;
    }

    /**
     * @param transporterWalletPrevBalance the transporterWalletPrevBalance to set
     */
    public void setTransporterWalletPrevBalance(Double transporterWalletPrevBalance) {
        this.transporterWalletPrevBalance = transporterWalletPrevBalance;
    }

    /**
     * @return the transporterWalletNewBalance
     */
    public Double getTransporterWalletNewBalance() {
        return transporterWalletNewBalance;
    }

    /**
     * @param transporterWalletNewBalance the transporterWalletNewBalance to set
     */
    public void setTransporterWalletNewBalance(Double transporterWalletNewBalance) {
        this.transporterWalletNewBalance = transporterWalletNewBalance;
    }

    /**
     * @return the passangerWalletId
     */
    public Integer getPassangerWalletId() {
        return passangerWalletId;
    }

    /**
     * @param passangerWalletId the passangerWalletId to set
     */
    public void setPassangerWalletId(Integer passangerWalletId) {
        this.passangerWalletId = passangerWalletId;
    }

    /**
     * @return the passangerWalletPrevBalance
     */
    public Double getPassangerWalletPrevBalance() {
        return passangerWalletPrevBalance;
    }

    /**
     * @param passangerWalletPrevBalance the passangerWalletPrevBalance to set
     */
    public void setPassangerWalletPrevBalance(Double passangerWalletPrevBalance) {
        this.passangerWalletPrevBalance = passangerWalletPrevBalance;
    }

    /**
     * @return the passangerWalletNewBalance
     */
    public Double getPassangerWalletNewBalance() {
        return passangerWalletNewBalance;
    }

    /**
     * @param passangerWalletNewBalance the passangerWalletNewBalance to set
     */
    public void setPassangerWalletNewBalance(Double passangerWalletNewBalance) {
        this.passangerWalletNewBalance = passangerWalletNewBalance;
    }

    /**
     * @return the dateTime
     */
    public Date getDateTime() {
        return dateTime;
    }

    /**
     * @param dateTime the dateTime to set
     */
    public void setDateTime(Date dateTime) {
        this.dateTime = dateTime;
    }

    /**
     * @return the transporterWalletId
     */
    public Integer getTransporterWalletId() {
        return transporterWalletId;
    }

    /**
     * @param transporterWalletId the transporterWalletId to set
     */
    public void setTransporterWalletId(Integer transporterWalletId) {
        this.transporterWalletId = transporterWalletId;
    }
    
    
}
