/*
* To change this license header, choose License Headers in Project Properties.
* To change this template file, choose Tools | Templates
* and open the template in the editor.
*/
package com.oltranz.IntercityTransport.entities;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author manzi
 */
@Entity
@Table(name = "wallets_transactions")
public class WalletTransaction implements Serializable {
    private static final long serialVersionUID = 1L;
    
    /**
     * @return the serialVersionUID
     */
    public static long getSerialVersionUID() {
        return serialVersionUID;
    }
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    
     @Column(name = "id")
    private Long id;
    
     @Column(name = "wallet_id")
    private Integer walletId;
    
     @Column(name = "amount")
    private Double amount;
    
     @Column(name = "refTransType_id")
    private Integer refTransTypeId;
    
     @Column(name = "refTrans_id")
    private Long refTransId;
    
     @Column(name = "prevBalance")
    private Double prevBalance;
    
    @Column(name = "newBalance")
    private Double newBalance;
    
    @Column(name = "date_time", nullable = false)
    @Temporal(TemporalType.DATE)
    private Date dateTime;
    
    public Long getId() {
        return id;
    }
    
    public void setId(Long id) {
        this.id = id;
    }
    
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }
    
    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof WalletTransaction)) {
            return false;
        }
        WalletTransaction other = (WalletTransaction) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }
    
    @Override
    public String toString() {
        return "com.oltranz.IntercityTransport.Entities.walletTransaction[ id=" + id + " ]";
    }
    
    /**
     * @return the walletId
     */
    public Integer getWalletId() {
        return walletId;
    }
    
    /**
     * @param walletId the walletId to set
     */
    public void setWalletId(Integer walletId) {
        this.walletId = walletId;
    }
    
    /**
     * @return the amount
     */
    public Double getAmount() {
        return amount;
    }
    
    /**
     * @param amount the amount to set
     */
    public void setAmount(Double amount) {
        this.amount = amount;
    }
    
    /**
     * @return the refTransTypeId
     */
    public Integer getRefTransTypeId() {
        return refTransTypeId;
    }
    
    /**
     * @param refTransTypeId the refTransTypeId to set
     */
    public void setRefTransTypeId(Integer refTransTypeId) {
        this.refTransTypeId = refTransTypeId;
    }
    
    /**
     * @return the refTransId
     */
    public Long getRefTransId() {
        return refTransId;
    }
    
    /**
     * @param refTransId the refTransId to set
     */
    public void setRefTransId(Long refTransId) {
        this.refTransId = refTransId;
    }
    
    /**
     * @return the prevBalance
     */
    public Double getPrevBalance() {
        return prevBalance;
    }
    
    /**
     * @param prevBalance the prevBalance to set
     */
    public void setPrevBalance(Double prevBalance) {
        this.prevBalance = prevBalance;
    }
    
    /**
     * @return the newBalance
     */
    public Double getNewBalance() {
        return newBalance;
    }
    
    /**
     * @param newBalance the newBalance to set
     */
    public void setNewBalance(Double newBalance) {
        this.newBalance = newBalance;
    }
    
    /**
     * @return the dateTime
     */
    public Date getDateTime() {
        return dateTime;
    }
    
    /**
     * @param dateTime the dateTime to set
     */
    public void setDateTime(Date dateTime) {
        this.dateTime = dateTime;
    }
    
}
