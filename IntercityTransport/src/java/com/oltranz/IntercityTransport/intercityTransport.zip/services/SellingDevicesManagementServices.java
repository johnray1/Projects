/*
* To change this license header, choose License Headers in Project Properties.
* To change this template file, choose Tools | Templates
* and open the template in the editor.
*/
package com.oltranz.IntercityTransport.services;

import com.oltranz.IntercityTransport.entities.SellingDevice;
import com.oltranz.IntercityTransport.models.ResultObject;
import com.oltranz.IntercityTransport.beans.SellingDevicesManager;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

/**
 *
 * @author manzi
 */
@Stateless
@Path("SellingDevicesServices")
public class SellingDevicesManagementServices {
    
    @EJB
            SellingDevicesManager SellingDevicesManagerEJB;
    
    @POST
    @Path("sellingDevice/new")
    @Consumes({"application/xml", "application/json"})
    public String createSellingDevice(SellingDevice sellingDevice) {
        ResultObject result= SellingDevicesManagerEJB.createSellingDevice(sellingDevice);
        return result.getJsonFormat();
    }
    
    @POST
    @Path("sellingDevice/edit")
    @Consumes({"application/xml", "application/json"})
    public String editSellingDevice(SellingDevice sellingDevice) {
        ResultObject result= SellingDevicesManagerEJB.updateSellingDevice(sellingDevice);
        return result.getJsonFormat();
    }
    
    @GET
    @Path("sellingDevice/{imei}")
    @Produces({"application/xml", "application/json"})
    public String find(@PathParam("imei") String imei) {
        ResultObject result= SellingDevicesManagerEJB.getSellingDevice(imei);
        return result.getJsonFormat();
    }
    
    @GET
    @Path("sellingDevices")
    @Produces({"application/xml", "application/json"})
    public String getAllSellingDevices() {
        ResultObject result= SellingDevicesManagerEJB.getAllSellingDevicesList();
        return result.getJsonFormat();
    }
    
    @GET
    @Path("transporterSellingDevices/{transporterId}")
    @Produces({"application/xml", "application/json"})
    public String getTransporterSellingDevices(@PathParam("transporterId") Integer transporterId) {
        ResultObject result= SellingDevicesManagerEJB.getTransporterSellingDevicesList(transporterId);
        return result.getJsonFormat();
    }
    
    @PUT
    @Path("sellingDeviceToBus/{imei}/{numberPlate}")
    public String sellingDeviceToBus(@PathParam("imei") String imei,@PathParam("numberPlate") String numberPlate) {
        ResultObject result= SellingDevicesManagerEJB.attacheSellingDeviceToBus(imei, numberPlate);
        return result.getJsonFormat();
    }
    
    @DELETE
    @Path("sellingDeviceFromBus/{imei}")
    public String sellingDeviceFromCurrentBus(@PathParam("imei") String imei) {
        ResultObject result= SellingDevicesManagerEJB.detachSellingDeviceFromCurrentBus(imei);
        return result.getJsonFormat();
    }
    
}
