/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.oltranz.IntercityTransport.services;

import com.oltranz.IntercityTransport.beans.SalesManager;
import com.oltranz.IntercityTransport.models.CardPaymentOnPOSRequestModel;
import com.oltranz.IntercityTransport.models.ResultObject;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;

/**
 *
 * @author manzi
 */
@Stateless
@Path("salesServices")
public class SaleServices {
   
    @EJB
    SalesManager salesManagerEJB;
   
    @POST
    @Path("cardPaymentOnPOSRequest")
    @Consumes({"application/xml", "application/json"})
    public String cardPaymentOnPOSRequest(CardPaymentOnPOSRequestModel payment) {
       
        ResultObject result= salesManagerEJB.processCardPaymentOnPOSRequest(payment);
        return result.getJsonFormat();
    }

   
   

}
